/*
SQLyog Community v12.02 (32 bit)
MySQL - 5.5.29 : Database - designer
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`designer` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `designer`;

/*Table structure for table `dreg` */

DROP TABLE IF EXISTS `dreg`;

CREATE TABLE `dreg` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `dreg` */

insert  into `dreg`(`id`,`name`,`password`,`dob`,`email`,`contact`,`location`) values (3,'null','null','null','null','null','null'),(4,'null','null','null','null','null','null'),(5,'null','null','null','null','null','null'),(6,'null','null','null','null','null','null'),(7,'null','null','null','null','null','null'),(8,'Abi','null','12/12/1999','  goklul@gmail.com','67867868567','Chennai'),(9,'AbiShankar','null','03/11/1999 ','  goklul@gmail.com','789678675','Chennai'),(10,'Maran','1234','12/12/1999','maran21@gmail.com','8678567564','Chennai'),(11,'Maran','1234','12/12/1999','maran21@gmail.com','8678567564','Chennai');

/*Table structure for table `mreg` */

DROP TABLE IF EXISTS `mreg`;

CREATE TABLE `mreg` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `mreg` */

insert  into `mreg`(`id`,`name`,`password`,`dob`,`email`,`contact`,`location`) values (1,'Magesh','1234','12/12/1999','  goklul@gmail.com','9867867786','Chennai');

/*Table structure for table `upload` */

DROP TABLE IF EXISTS `upload`;

CREATE TABLE `upload` (
  `pid` varchar(200) DEFAULT NULL,
  `pname` varchar(200) DEFAULT NULL,
  `date` varchar(200) DEFAULT NULL,
  `bdate` varchar(200) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `upload` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
