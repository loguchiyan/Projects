/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clo;

/**
 *
 * @author david
 */
public class Constant {
    public static String file="D://david/";
}
   