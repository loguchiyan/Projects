/*
SQLyog Community v12.02 (32 bit)
MySQL - 5.5.29 : Database - designer
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`designer` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `designer`;

/*Table structure for table `dreg` */

DROP TABLE IF EXISTS `dreg`;

CREATE TABLE `dreg` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

/*Data for the table `dreg` */

insert  into `dreg`(`id`,`name`,`password`,`dob`,`email`,`contact`,`location`) values (16,'sibi','123','2023-05-03','sibi@gmail.com','9677870347','chennai');

/*Table structure for table `mreg` */

DROP TABLE IF EXISTS `mreg`;

CREATE TABLE `mreg` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `mname` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `contact` varchar(200) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `mreg` */

insert  into `mreg`(`id`,`mname`,`password`,`dob`,`email`,`contact`,`location`) values (5,'guna','123','2023-05-04','guna@gmail.com','9887645436','vellore');

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `sno` int(200) NOT NULL AUTO_INCREMENT,
  `mname` varchar(200) DEFAULT NULL,
  `pid` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `pname` varchar(200) DEFAULT NULL,
  `bname` varchar(200) DEFAULT NULL,
  `cost` varchar(200) DEFAULT NULL,
  `bamt` varchar(200) DEFAULT NULL,
  `ctype` varchar(200) DEFAULT NULL,
  `card` varchar(200) DEFAULT NULL,
  `ifsc` varchar(200) DEFAULT NULL,
  `cvv` varchar(200) DEFAULT NULL,
  `branch` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT '10% Interest Recevied',
  `status1` varbinary(200) DEFAULT 'waiting',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `orders` */

insert  into `orders`(`sno`,`mname`,`pid`,`name`,`pname`,`bname`,`cost`,`bamt`,`ctype`,`card`,`ifsc`,`cvv`,`branch`,`status`,`status1`) values (11,'guna','01','sibi','Frame art','null','800','500',NULL,NULL,NULL,NULL,NULL,'10% Interest Recevied','Accept');

/*Table structure for table `ordersta` */

DROP TABLE IF EXISTS `ordersta`;

CREATE TABLE `ordersta` (
  `sno` int(22) NOT NULL AUTO_INCREMENT,
  `mname` varchar(222) DEFAULT NULL,
  `pid` varchar(222) DEFAULT NULL,
  `name` varchar(222) DEFAULT NULL,
  `pname` varchar(222) DEFAULT NULL,
  `bname` varchar(222) DEFAULT NULL,
  `cost` varchar(222) DEFAULT NULL,
  `bamt` varchar(222) DEFAULT NULL,
  `ctype` varchar(222) DEFAULT NULL,
  `card` varchar(222) DEFAULT NULL,
  `ifsc` varchar(222) DEFAULT NULL,
  `cvv` varchar(222) DEFAULT NULL,
  `branch` varchar(222) DEFAULT NULL,
  `status` varchar(222) DEFAULT 'Waiting',
  `datee` varchar(222) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `ordersta` */

insert  into `ordersta`(`sno`,`mname`,`pid`,`name`,`pname`,`bname`,`cost`,`bamt`,`ctype`,`card`,`ifsc`,`cvv`,`branch`,`status`,`datee`) values (5,'guna','01','sibi','Frame art','iob','800','500','Credit Card','473269323289739','IOB234723','1234','salem','10% Commision Recevied',NULL);

/*Table structure for table `request` */

DROP TABLE IF EXISTS `request`;

CREATE TABLE `request` (
  `sno` int(222) NOT NULL AUTO_INCREMENT,
  `mname` varchar(200) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `pid` varchar(200) DEFAULT NULL,
  `pname` varchar(200) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `datee` varchar(200) DEFAULT NULL,
  `cost` varchar(200) DEFAULT NULL,
  `bdate` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT 'Waiting',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

/*Data for the table `request` */

insert  into `request`(`sno`,`mname`,`name`,`pid`,`pname`,`image`,`datee`,`cost`,`bdate`,`status`) values (51,'guna','sibi','01 ','Frame art ','null','null','800 ','null','Waiting');

/*Table structure for table `upload` */

DROP TABLE IF EXISTS `upload`;

CREATE TABLE `upload` (
  `sno` int(222) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `pid` varchar(200) DEFAULT NULL,
  `pname` varchar(200) DEFAULT NULL,
  `cost` varchar(200) DEFAULT NULL,
  `bdate` varchar(200) DEFAULT NULL,
  `datee` varchar(200) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `upload` */

insert  into `upload`(`sno`,`name`,`pid`,`pname`,`cost`,`bdate`,`datee`,`image`) values (10,'sibi','01','Frame art','800','2 Days Remaining','22/7/2000 & 10:00am','bidding image.jpg');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
